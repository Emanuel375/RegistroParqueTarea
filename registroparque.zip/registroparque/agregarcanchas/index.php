

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRO</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <?php
    include("conexion.php");

    // Verificar la conexión
    if (!$conexion) {
        die("Conexión fallida: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM canchas";
    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($conexion));
    }
    ?>
    <div class="container">
        <h1><b>RESERVAS DE CANCHAS</b></h1>
        <p><h3>Calle : Ramón Aspillaga N° 901 - Pisco</h3></p>

        <div class="ajustar-derecha btn-group"> 
            <a href="../index.php" class="btn">VOLVER</a>
            <a href="../cerrar.php" class="btn">CERRAR SESION</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>NOMBRE</th>
                    <th>AGENDADO</th>
                    <th>ACCIONES</th>
                </tr>
            </thead>
            <tbody>
                <?php   
                while ($filas = mysqli_fetch_assoc($resultado)) {
                ?>
                <tr>
                    <td data-label="NOMBRE"><?php echo htmlspecialchars($filas['CANCHA']); ?></td>
                    <td data-label="AGENDADO"><?php echo htmlspecialchars($filas['AGENDADO']); ?></td>
                    <td data-label="ACCIONES">
                        <a href="editar.php?id=<?php echo $filas['id'] ?>" class="btn editar">EDITAR</a>
                        <a href="reservar.php?id=<?php echo $filas['id'] ?>" class="btn eliminar">RESERVAR</a>
                    </td>
                </tr>
                <?php
                }
                mysqli_free_result($resultado);
                ?>
            </tbody>
        </table>
    </div>
    <?php
    mysqli_close($conexion);
    ?>
</body>
</html>
