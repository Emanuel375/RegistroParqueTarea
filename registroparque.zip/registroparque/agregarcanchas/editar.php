<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Equipo</title>
    <link rel="stylesheet" href="editar.css"> 
</head>
<body>
<?php
include("conexion.php");

// Verificar la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $lugar = mysqli_real_escape_string($conexion, $_POST['lugar']);
    $agendado = mysqli_real_escape_string($conexion, $_POST['agendado']);
    $telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);

    $sql = "UPDATE canchas SET AGENDADO='$agendado' WHERE id='$id'";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: ../reservados/index.php");
        header("Location: ../reservados_cliente/index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

// Obtener los datos actuales del registro
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conexion, $_GET['id']);
    $sql = "SELECT * FROM canchas WHERE id='$id'";
    
    $result = mysqli_query($conexion, $sql);
    $registro = mysqli_fetch_assoc($result);
} else {
    echo "ID no especificado.";
    exit;
}

mysqli_close($conexion);
?>
<div class="container">
    <h1>Editar Fecha</h1>
    <h2>¿Para qué fecha desea reservar esta cancha?</h2>
    <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($registro['id']); ?>">
        <label for="agendado">Agendado</label>
        <input type="date" id="agendado" name="agendado" value="<?php echo htmlspecialchars($registro['agendado']); ?>
        <button type="submit" class="guardar-btn">Guardar</button>
    </form>
</div>
</body>
</html>
