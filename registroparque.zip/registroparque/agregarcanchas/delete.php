<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar equipo</title>
    <link rel="stylesheet" href="style.css"> 
</head>
<body>
<?php
include("conexion.php");

// Verificar la conexiÃ³n
if (!$conexion) {
    die("ConexiÃ³n fallida: " . mysqli_connect_error());
}

// Procesar la ediciÃ³n
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'update') {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $lugar = mysqli_real_escape_string($conexion, $_POST['lugar']);
    $agendado = mysqli_real_escape_string($conexion, $_POST['agendado']);

    $sql = "UPDATE registro_parque SET Eliminado='1' WHERE id='$id'";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

// Procesar la eliminaciÃ³n
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'delete') {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    
    $sql = "DELETE FROM registro_parque WHERE id='$id'";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

// Obtener los datos actuales del registro
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conexion, $_GET['id']);
    $sql = "SELECT * FROM registro_parque WHERE id='$id'";
    $result = mysqli_query($conexion, $sql);
    $registro = mysqli_fetch_assoc($result);
} else {
    echo "ID no especificado.";
    exit;
}

mysqli_close($conexion);
?>
    <h1>Â¿Estas seguro de eliminar?</h1>
        <form method="post" action="">  
        <h2><input type="hidden" name="id" value="<?php echo htmlspecialchars($registro['id']); ?>">
        <input type="hidden" name="action" value="update"></h2>

       <h2><label for="nombre">Nombre</label>
        <input type="text" id="nombre" disabled = true name="nombre" value="<?php echo htmlspecialchars($registro['nombre']); ?>" required><br><br></h2>

        <h2><b><label for="lugar">Lugar</label></b>
        <input type="text" id="lugar" disabled = true name="lugar" value="<?php echo htmlspecialchars($registro['lugar']); ?>" required><br><br></h2>

        <h2><b><label for="agendado">Agendado</label></b>
        <b><input type="date" id="agendado" disabled = true name="agendado" value="<?php echo htmlspecialchars($registro['agendado']); ?>" required><br><br></b></h2>

    </form>
    <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($registro['id']); ?>">
        <input type="hidden" name="action" value="delete">
        <h3><button type="submit" class="eliminar-btn">Eliminar</button></h3>
        
    </form>
</body>
</html>