<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro del parque zonal</title>
    <link rel="stylesheet" href="style.css">    
</head>
<body>
    <?php
    include("conexion.php");

    // Verificar la conexión
    if (!$conexion2) {
        die("Conexión fallida: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM canchas";
    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($conexion));
    }
    ?>
    <h1><b>PARQUE ZONAL </b> </h1>
    <P class="class"><h3>Calle : Ramón Aspillaga N° 901 - Pisco</h3></P>

<div class="ajustar-derecha"> 

        <a href="buscar.php">BUSCAR EQUIPO</a>
        <a href="telefono.php">INFO. PARQUE ZONAL</a>
        <a href="http://localhost/Login%20and%20Register/index.php">INGRESAR COMO ADMINISTRADOR</a>
        <a href="http://localhost/registroparque/index.php">VOLVER</a>
</div>
<br>
<BR></BR>
    <table border="1">
        <thead>
            <tr>
                <th>NOMBRE</th>
                <th>ZONA</th>
                <th>AGENDADO</th>

                
            </tr>
        </thead>
        <tbody>
            <?php
            while ($filas = mysqli_fetch_assoc($resultado)) {
            ?>
            <tr>
                <td><?php echo htmlspecialchars($filas['CANCHA']); ?></td>
                <td><?php echo htmlspecialchars($filas['AGENDADO']); ?>  </td>
                <td><?php echo htmlspecialchars($filas['RESERVADO']); ?></td>

            </tr>
            <?php
            }
            mysqli_free_result($resultado);
            ?>
        </tbody>
    </table>
    <?php
    mysqli_close($conexion);
    ?>
</body>
</html>