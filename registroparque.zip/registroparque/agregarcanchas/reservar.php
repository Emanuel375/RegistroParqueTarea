<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>¿QUE CANCHA DESEA RESERVAR?</title>
    <link rel="stylesheet" href="reservar.css">    
</head>
<body>
<?php
include("conexion.php");

// Verificar la conexion
if (!$conexion) {
    die("Conexion fallida: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $lugar = mysqli_real_escape_string($conexion, $_POST['lugar']);
    $agendado = mysqli_real_escape_string($conexion, $_POST['agendado']);
    $telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
    
    $sql = "INSERT INTO registro_parque (nombre, lugar, agendado, telefono) VALUES ('$nombre', '$lugar', '$agendado', '$telefono')";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: ../reservados/index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}
mysqli_close($conexion);
?>
<h1>¿PARA QUÉ FECHA DESEA RESERVAR?</h1><br>
    <br>
    <form method="post" action="">
        <input type="hidden" id="id" name="id" value="id"> 
        <label for="agendado">Agendado</label>
        <input type="date" id="agendado" name="agendado" required><br><br>
        
        
        <button type="submit" class="guardar-btn">Reservar</button>
    </form>
</body>
</html>