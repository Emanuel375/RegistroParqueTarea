<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro del parque zonal</title>
    <link rel="stylesheet" href="style.css">    
</head>
<body>
    <?php
    include("conexion.php");

    // Verificar la conexión
    if (!$conexion) {
        die("Conexión fallida: " . mysqli_connect_error());
    }

    // Procesar el formulario de búsqueda
    $busqueda = "";
    if (isset($_GET['buscar'])) {
        $busqueda = $_GET['buscar'];
        $sql = "SELECT * FROM registro_parque WHERE nombre LIKE '%$busqueda%' OR lugar LIKE '%$busqueda%' OR agendado LIKE '%$busqueda%'";
    } else {
        $sql = "SELECT * FROM registro_parque";
    }

    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($conexion));
    }
    ?>
    <h1>¿QUE EQUIPO DESEAS BUSCAR?</h1>
    <br>
    <h3><a href="buscar.php">INGRESA DATOS</a></h3>
    <!-- Formulario de búsqueda -->
    <form action="" method="GET">
        <input type="text" name="buscar" placeholder="Buscar por nombre, lugar o agendado" value="<?php echo htmlspecialchars($busqueda); ?>">
        <button type="submit">Buscar</button>
    </form>

    <br>

    <table border="1">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Lugar</th>
                <th>Agendado</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($filas = mysqli_fetch_assoc($resultado)) {
            ?>
            <tr>
                <td><?php echo htmlspecialchars($filas['nombre']); ?></td>
                <td><?php echo htmlspecialchars($filas['lugar']); ?></td>
                <td><?php echo htmlspecialchars($filas['agendado']); ?></td>

            </tr>
            <?php
            }
            mysqli_free_result($resultado);
            ?>
        </tbody>
    </table>
    <?php
    mysqli_close($conexion);
    ?>
</body>
</html>
