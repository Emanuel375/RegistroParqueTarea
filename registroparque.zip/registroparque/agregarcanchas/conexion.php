<?php
$dbname= "equipos";
$dbuser= "root";
$dbhost= "localhost";
$dbpass= "";

$conexion= mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

?>