<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar equipo</title>
    <link rel="stylesheet" href="editar.css">    
</head>
<body>
<?php
include("conexion.php");

// Verificar la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $zona = mysqli_real_escape_string($conexion, $_POST['zona']);
    $agendado = mysqli_real_escape_string($conexion, $_POST['agendado']);
    $telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);

    $sql = "UPDATE registro_parque SET nombre='$nombre', lugar='$zona', agendado='$agendado', telefono='$telefono' WHERE id='$id'";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

// Obtener los datos actuales del registro
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conexion, $_GET['id']);
    $sql = "SELECT * FROM registro_parque WHERE id='$id'";
    $result = mysqli_query($conexion, $sql);
    $registro = mysqli_fetch_assoc($result);
} else {
    echo "ID no especificado.";
    exit;
}

mysqli_close($conexion);
?>
    <div class="form-container">
        <h1>Editar equipo</h1>
        <form method="post" action="">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($registro['id']); ?>">

            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($registro['nombre']); ?>" required>

            <label for="zona">Zona</label>
            <input type="text" id="zona" name="zona" value="<?php echo htmlspecialchars($registro['lugar']); ?>" required>

            <label for="telefono">Teléfono</label>
            <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($registro['telefono']); ?>" required>

            <label for="agendado">Agendado</label>
            <input type="date" id="agendado" name="agendado" value="<?php echo htmlspecialchars($registro['agendado']); ?>" required>

            <button type="submit" class="guardar-btn">Guardar</button>
        </form>
    </div>
</body>
</html>
