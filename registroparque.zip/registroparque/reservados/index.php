<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro del parque zonal</title>
    <link rel="stylesheet" href="reservar2.css">    
</head>
<body>
    <?php
    include("conexion.php");

    // Verificar la conexión
    if (!$conexion) {
        die("Conexión fallida: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM canchas";
    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($conexion));
    }
    ?>
    <div class="container">
        <h1>CANCHAS RESERVADAS DEL PARQUE ZONAL</h1>
        <p class="address">Calle: Ramón Aspillaga N° 901 - Pisco</p>

        <div class="button-group"> 
            <a href="../agregarcanchas/index.php" class="btn">VOLVER</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>NOMBRE</th>
                    <th>AGENDADO</th>
                    <th>RESERVADOS</th>
                </tr>
            </thead>
            <tbody>
                <?php   
                while ($filas = mysqli_fetch_assoc($resultado)) {
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($filas['CANCHA']); ?></td>
                    <td><?php echo htmlspecialchars($filas['AGENDADO']); ?></td>
                    <td>RESERVADO</td>
                </tr>
                <?php
                }
                mysqli_free_result($resultado);
                ?>
            </tbody>
        </table>
    </div>

    <?php
    mysqli_close($conexion);
    ?>
</body>
</html>
