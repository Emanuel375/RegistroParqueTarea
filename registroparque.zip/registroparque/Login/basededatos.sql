CREATE DATABASE RegistroCanchasFutbol;
USE RegistroCanchasFutbol;

-- Crear tabla Usuarios
CREATE TABLE Usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefono VARCHAR(15),
    contraseña VARCHAR(100) NOT NULL
);

-- Crear tabla Canchas
CREATE TABLE Canchas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ubicación VARCHAR(255) NOT NULL,
    tipo VARCHAR(50),
    capacidad INT,
    disponible BOOLEAN DEFAULT TRUE
);

-- Crear tabla Reservas
CREATE TABLE Reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    cancha_id INT,
    usuario_id INT,
    FOREIGN KEY (cancha_id) REFERENCES Canchas(id),
    FOREIGN KEY (usuario_id) REFERENCES Usuarios(id)
);

-- Crear tabla Administradores
CREATE TABLE Administradores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefono VARCHAR(15),
    contraseña VARCHAR(100) NOT NULL
);

-- Crear tabla Administración (relaciona Administradores con Canchas)
CREATE TABLE Administracion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    administrador_id INT,
    cancha_id INT,
    FOREIGN KEY (administrador_id) REFERENCES Administradores(id),
    FOREIGN KEY (cancha_id) REFERENCES Canchas(id)
);
