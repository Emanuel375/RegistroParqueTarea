<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar equipo</title>
    <link rel="stylesheet" href="style.css"> 
    <style>
        /* Estilos generales */
        body {
            font-family: 'Arial', sans-serif;
            background: url('imagenes/fondo.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        h1 {
            color: #0d2523;
            margin-top: 50px;
            font-size: 2rem;
        }

        h2 {
            color: #37b963;
            font-size: 1.2rem;
        }

        form {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 1rem;
            background-color: #f9f9f9;
            cursor: not-allowed;
        }

        .eliminar-btn {
            background-color: #e74c3c;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: 0 auto;
        }

        .eliminar-btn:hover {
            background-color: #c0392b;
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
                height: auto;
            }

            form {
                width: 100%;
                box-shadow: none;
            }

            h1 {
                font-size: 1.5rem;
                margin-top: 20px;
            }

            h2 {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
<?php
include("conexion.php");

// Verificar la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Procesar la edición
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'update') {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $lugar = mysqli_real_escape_string($conexion, $_POST['lugar']);
    $agendado = mysqli_real_escape_string($conexion, $_POST['agendado']);

    $sql = "UPDATE registro_parque SET Eliminado='1' WHERE id='$id'";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

// Procesar la eliminación
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'delete') {
    $id = mysqli_real_escape_string($conexion, $_POST['id']);
    
    $sql = "DELETE FROM registro_parque WHERE id='$id'";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

// Obtener los datos actuales del registro
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conexion, $_GET['id']);
    $sql = "SELECT * FROM registro_parque WHERE id='$id'";
    $result = mysqli_query($conexion, $sql);
    $registro = mysqli_fetch_assoc($result);
} else {
    echo "ID no especificado.";
    exit;
}

mysqli_close($conexion);
?>
    <h1>¿Estás seguro de eliminar?</h1>
    <form method="post" action="">  
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($registro['id']); ?>">
        <input type="hidden" name="action" value="update">
        <h2><label for="nombre">Nombre</label></h2>
        <input type="text" id="nombre" disabled="true" name="nombre" value="<?php echo htmlspecialchars($registro['nombre']); ?>" required><br>
        <h2><label for="lugar">Lugar</label></h2>
        <input type="text" id="lugar" disabled="true" name="lugar" value="<?php echo htmlspecialchars($registro['lugar']); ?>" required><br>
        <h2><label for="agendado">Agendado</label></h2>
        <input type="date" id="agendado" disabled="true" name="agendado" value="<?php echo htmlspecialchars($registro['agendado']); ?>" required><br>
    </form>
    <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($registro['id']); ?>">
        <input type="hidden" name="action" value="delete">
        <button type="submit" class="eliminar-btn">Eliminar</button>
    </form>
</body>
</html>
