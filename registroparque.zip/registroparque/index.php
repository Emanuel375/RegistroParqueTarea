<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('location:vista/index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro del parque zonal</title>
    <link rel="stylesheet" href="style.css">    
</head>
<body>
    <?php
    include("conexion.php");

    // Verificar la conexión
    if (!$conexion) {
        die("Conexión fallida: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM registro_parque";
    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($conexion));
    }
    ?>
    <h1>PARQUE ZONAL </h1>
    <P class="class"><h3>Calle : Ramón Aspillaga N° 901 - Pisco</h3></P>

<div class="ajustar-derecha"> 
        <a href="auditoria_adm/index.php">AUDITORIA</a>
        <a href="crear.php">AGREGAR EQUIPO</a>
        <a href="buscar.php">BUSCAR EQUIPO</a>
        <a href="agregarcanchas/index.php">RESERVAR CANCHA</a>
        <a href="cerrar.php">CERRAR SESION</a>
</div>
<br>
<BR></BR>
    <table border="1">
        <thead>
            <tr>
                <th>NOMBRE</th>
                <th>ZONA</th>
                <th>AGENDADO</th>
                <th>TELEFONOS DE USUARIOS</th>
                <th>ACCIONES</th>
                
            </tr>
        </thead>
        <tbody>
    <?php
    while ($filas = mysqli_fetch_assoc($resultado)) {
    ?>
    <tr>
        <td><?php echo htmlspecialchars($filas['nombre']); ?></td>
        <td><?php echo htmlspecialchars($filas['lugar']); ?></td>
        <td><?php echo htmlspecialchars($filas['agendado']); ?></td>
        <td><?php echo htmlspecialchars($filas['telefono']); ?></td>
        <td>
            <div class="button-container">
                <a href="editar.php?id=<?php echo $filas['id']; ?>" class="editar">Editar</a>
                <a href="delete.php?id=<?php echo $filas['id']; ?>" class="eliminar">Eliminar</a>
            </div>
        </td>
    </tr>
    <?php
    }
    mysqli_free_result($resultado);
    ?>
</tbody>

    </table>
    <?php
    mysqli_close($conexion);
    ?>
        <footer>
        <p>&copy; 2024 Registro del Parque Zonal. Universidad Autonoma de Ica.</p>
    </footer>
</body>
</html>
