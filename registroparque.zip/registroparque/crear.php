<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AGREGAR EQUIPO</title>
    <link rel="stylesheet" href="agregar.css"> 
    <style>
        /* Estilos generales */
        body {
            font-family: 'Arial', sans-serif;
            background: url('imagenes/fondo.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
        }

        h1 {
            color: #0d2523;
            text-align: center;
            margin-bottom: 20px;
            font-size: 2rem;
        }

        .form-container {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #0d2523;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 1rem;
            background-color: #f9f9f9;
        }

        .guardar-btn {
            background-color: #2ecc71;
            color: #fff;
            border: none;
            padding: 15px;
            font-size: 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-align: center;
            width: 100%;
        }

        .guardar-btn:hover {
            background-color: #27ae60;
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
                height: auto;
            }

            .container {
                width: 100%;
                padding: 20px;
            }

            h1 {
                font-size: 1.5rem;
            }

            input[type="text"],
            input[type="date"],
            .guardar-btn {
                padding: 10px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
<?php
include("conexion.php");

// Verificar la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $lugar = mysqli_real_escape_string($conexion, $_POST['lugar']);
    $agendado = mysqli_real_escape_string($conexion, $_POST['agendado']);
    $telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
    
    $sql = "INSERT INTO registro_parque (nombre, lugar, agendado, telefono) VALUES ('$nombre', '$lugar', '$agendado', '$telefono')";
    
    if (mysqli_query($conexion, $sql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
    }
}

mysqli_close($conexion);
?>
    <div class="container">
        <h1>AGREGAR EQUIPO</h1><br>
        <div class="form-container">
            <form method="post" action="">

                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" required><br><br>

                <label for="lugar">Lugar</label>
                <input type="text" id="lugar" name="lugar" required><br><br>

                <label for="agendado">Agendado</label>
                <input type="date" id="agendado" name="agendado" required><br><br>

                <label for="telefono">Teléfono</label>
                <input type="text" id="telefono" name="telefono" required><br><br>

                <button type="submit" class="guardar-btn">Guardar</button>

            </form>
        </div>
    </div>
</body>
</html>
