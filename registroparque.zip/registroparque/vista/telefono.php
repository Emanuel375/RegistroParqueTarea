<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="telefonovista.css">    
</head>
<body>
    <br>
    <h1>teléfono : 942636335 </h1> <BR></BR>
    <h2>dirección : Calle : Ramón Aspillaga N° 901 - Pisco</h2>
    <BR></BR>
    <p><h1>VISTA PÚBLICA</h1></p>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3876.1843382615953!2d-76.21274829018355!3d-13.707282686624382!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x91106f7259cdc65b%3A0x5e32915b3db88bc9!2sParque%20Zonal!5e0!3m2!1ses-419!2spe!4v1719164411893!5m2!1ses-419!2spe" width="1337" height="621" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>;
    <br>
    

</body>
</html>