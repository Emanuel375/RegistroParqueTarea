
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro del parque zonal</title>
    <link rel="stylesheet" href="stylevista.css">    
</head>
<body>
    <?php
    include("conexion.php");

    // Verificar la conexión
    if (!$conexion) {
        die("Conexión fallida: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM registro_parque";
    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        die("Error en la consulta: " . mysqli_error($conexion));
    }
    ?>
    <h1><b>PARQUE ZONAL </b> </h1>
    <P class="class"><h3>Calle : Ramón Aspillaga N° 901 - Pisco</h3></P>

<div class="ajustar-derecha"> 
        <a href="../auditoria/index.php">AUDITORIA</a>
        <a href="../reservados_cliente/index.php">VER CANCHAS</a>
        <a href="buscar.php">BUSCAR EQUIPO</a>
        <a href="telefono.php">INFO. PARQUE ZONAL</a>
        <a href="../Login/index-login.php">INGRESAR</a>

</div>
    <table border="1">
        <thead>
            <tr>
                <th>NOMBRE</th>
                <th>ZONA</th>
                <th>AGENDADO</th>

                
            </tr>
        </thead>
        <tbody>
            <?php
            while ($filas = mysqli_fetch_assoc($resultado)) {
            ?>
            <tr>
                <td><?php echo htmlspecialchars($filas['nombre']); ?></td>
                <td><?php echo htmlspecialchars($filas['lugar']); ?>  </td>
                <td><?php echo htmlspecialchars($filas['agendado']); ?></td>

            </tr>
            <?php
            }
            mysqli_free_result($resultado);
            ?>
        </tbody>    
    </table>
    <?php
    mysqli_close($conexion);
    ?>
    <footer>
        <p>&copy; 2024 Registro del Parque Zonal. Universidad Autonoma de Ica.</p>
    </footer>
</body>
</html>